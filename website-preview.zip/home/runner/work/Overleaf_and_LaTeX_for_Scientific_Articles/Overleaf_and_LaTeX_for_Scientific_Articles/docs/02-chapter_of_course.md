
# Writing with Overleaf

Now that you know the advantages of using overleaf, we will work through getting started writing a scientific manuscript with a template.

<img src="02-chapter_of_course_files/figure-html//1UgGtVn7RsqdQ4pJxDk_dueSyREHcH-uWTNAT27E2mG8_g1bb9ca840c8_0_360.png" title="Learning Objectives: 1. create an account with Overleaf, 2. Find a template to use, 3. Begin writing content" alt="Learning Objectives: 1. create an account with Overleaf, 2. Find a template to use, 3. Begin writing content" width="100%" style="display: block; margin: auto;" />

## Getting Started
